function [Z0, err] = sparse_tnn_apmm_noiseless(A, b,  transform,Xsize, alpha0, alpha3,opts)
% b: observation
% A: measurement 

tol = 1e-8; 
max_iter = 1000;
rho = 1.1;
rho_xi=1.1;
mu = 1e-6;
mu2=1e-6;
xi = 1e-6;
max_mu = 1e10;
DEBUG = 1;

if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'max_iter');    max_iter = opts.max_iter;    end
if isfield(opts, 'rho');         rho = opts.rho;              end
if isfield(opts, 'rho_xi');         rho = opts.rho;              end
if isfield(opts, 'mu');          mu = opts.mu;                end
if isfield(opts, 'max_mu');      max_mu = opts.max_mu;        end
if isfield(opts, 'DEBUG');       DEBUG = opts.DEBUG;          end



n1 = Xsize.n1;
n2 = Xsize.n2;
n3 = Xsize.n3;
X = zeros(n1,n2,n3);
dims=[n1,n2,n3];
Z0 = X;
Z3 = X;
m = length(b);
Y1 = zeros(m,1);
Y0 = X;
Y3 = X;
I = eye(n1*n2*n3);
%invA = (A'*A+(mu+mu2+xi)/mu*I)\I;
invA = (A'*A+3*I)\I;
iter = 0;
for iter = 1 : max_iter
    Xt = X;
    Z0t = Z0; 
    Z3t = Z3; 
    %invA = (A'*A+I)\I; 
    %para=(mu+mu2+xi)/(2*lambda);
    %invA = (A'*A+para*I)\I; 

    % update Z0
    %[Z0,Z0tnn] = prox_tnn(X-Y0/mu,1/mu,  transform);
    tempZ0 = (mu*(X-Y0/mu)+xi*Z0t)/(mu+xi);
    [Z0,Z0tnn] = prox_tnn(tempZ0, alpha0/(mu+xi),transform);
 

    % update X
    % vecX = invA*(A'*(-Y1/mu+b)+Y0(:)/mu+Z0(:));
    %X = reshape(vecX,n1,n2,n3);
    lambda=mu/2;
    P=(Z0*mu+Y0+mu2*Z3+Y3)/(mu+mu2); 
    tempvecX=((mu+mu2)*P(:)+xi*Xt(:))/(2*lambda);

     %P=(Z0*mu+Y0)/(mu); 
     %tempvecX=P(:); 
     vecX=invA*(A'*(-Y1/mu+b)+tempvecX);
     X=reshape(vecX,n1,n2,n3);

         %% Update Zk
         %Z3=Z0;
         k=3;
         tempZ3=(mu2*(X-Y3/mu2)+xi*Z3)/(mu2+xi);
         tempUZ3= lineartransform(tempZ3,transform);
         [unfolding_UZ3,norm12]=soft_row(Unfold(tempUZ3, dims, k),alpha3/(mu2+xi));
         UZ3=Fold(unfolding_UZ3, dims, k);

         Z3=inverselineartransform(UZ3,transform);
    
    dY1 = A*vecX-b;
    dY0 = Z0-X;
    dY3 = Z3-X;
    chgX = max(abs(Xt(:)-X(:)));
    chgZ0 = max(abs(Z0t(:)-Z0(:)));
    chgZ3 = max(abs(Z3t(:)-Z3(:)));
    chg = max([chgX chgZ0 chgZ3 max(abs(dY1)) max(abs(dY3(:)))]);
    if DEBUG
        if iter == 1 || mod(iter, 10) == 0
            obj = alpha0*Z0tnn+alpha3*norm12;  
            err = norm(dY1)^2+norm(dY0(:))^2+norm(dY3(:))^2;
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                    ', obj=' num2str(obj) ', err=' num2str(err)]); 
        end
    end
    
    if chg < tol
        break;
    end 
    Y1 = Y1 + mu*dY1;
    Y0 = Y0 + mu*dY0;
    Y3 = Y3 + mu*dY3;
    %mu = min(rho*mu,max_mu);    

    % Update mu, xi
    mu = min(rho*mu,max_mu);  
    mu2= min(rho*mu2,max_mu);
    xi = min(rho_xi*xi,max_mu);  
end
obj = alpha0*Z0tnn+alpha3*norm12;
err = norm(dY1)^2+norm(dY0(:))^2+norm(dY3(:))^2;

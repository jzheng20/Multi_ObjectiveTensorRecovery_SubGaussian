clear all;
clc;

%% Load data
X = double(imread('testimg.jpg'));
X=imresize(X, 0.1);
X = X/255;    
X=shiftdim(X,2);
maxP = max(abs(X(:)));
[n1,n2,n3] = size(X);
Xsize.n1 = n1;
Xsize.n2 = n2;
Xsize.n3 = n3;

%% Experiments setting
 delta=0;
 SamplingRate=0.3;
 m=floor(prod(size(X))*SamplingRate); 

 A = randn(m, prod(size(X)))/sqrt(m);
 z = randn(m, 1) * delta; %~N(0,delta^2); 
 b = A*X(:) + z;
    
 opts.DEBUG = 1; 
 opts.max_iter = 500;
 %define transform 
% transform.L = @fft; transform.l = n3; transform.inverseL = @ifft;
  % transform.L = @dct; transform.l = 1; transform.inverseL = @idct;
  %L = dftmtx(n3); transform.l = n3; transform.L = L;
%  L = dct(eye(n3)); transform.l = 1; transform.L = L;
% L = RandOrthMat(n3); transform.l = 1; transform.L = L;


%% Tuning the parameters
 alpha0 = [1];%50[0.001]; %[0.001,0.01,0.1,1,10,100];
 alpha3 = [0.0001,0.001];%0.0001[0.0001]; %[0.001,0.01,0.1,1,10,100];
 vecpsnr=[];param=[];
 lambda=[1];
 for a0=alpha0
     for a3=alpha3 
     %  [Xhat, err] =sparse_tnn_apmm_noiseless(A, b, transform, Xsize, a0, a3,opts);
   %[Xhat, err] =genetic_sparse_tnn_noiseless(A, b, transform, Xsize, alpha0, alpha3,opts,X);
    [Xhat, err] =sparse_tnn_wavelet_apmm_noiseless(A, b, Xsize, a0, a3,opts);
   psnr  = PSNR_high(X,Xhat,maxP)
      vecpsnr=[vecpsnr psnr];
      param=[param [a0; a3]]; 
     end
 end



filename=['image_sparse_tnn' datestr(now,30) '.mat'];%
save(filename);

function [cA,cD]=Gen_WaveletTransform(Y,m)

[n1,n2,n3]=size(Y);  
Y0=zeros(n1,n2,n3+m);
Y0(1:n1,1:n2,1:n3)=Y;
for ii=1:m 
Y0(1:n1,1:n2,n3+ii)=Y(1:n1,1:n2,n3);
end
cA=[];cD=[];
for i=1:n1 
    for j=1:n2
        x=Y0(i,j,:);
    [cA(i,j,:), cD(i,j,:)] = dwt(x(:), 'db4', 'mode', 'per');

end
end

end

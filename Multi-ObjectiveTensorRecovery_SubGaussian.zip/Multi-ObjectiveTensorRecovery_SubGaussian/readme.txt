
ima_data.mat: 50 color images randomly chosen from  BSD [1]

 



tun_images_noiseless: used for tuning parameters when the observation has no noise (sampling rate=0.3)

tun_images_noiseless: used for tuning parameters when the observation has noise (sampling rate=0.3)

demo_image: our method with given transform on BSD [1] (sampling rate=0.3)



[1] https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/bsds/ 
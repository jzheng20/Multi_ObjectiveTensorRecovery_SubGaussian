%  the soft threshold for rows of matrix by Jingjing Zheng: jjzheng233@gmail.com
%   argmin_X 1/2||Y-X||^2_F+tau||X||_1,2

function [X,norm12] = soft_row(Y,tau)
norm12=0;
X=zeros(size(Y));
m=size(Y,1);
for i=1:m
    y2=norm(Y(i,:),'fro');
    if y2>tau
X(i,:)= max(y2-tau,0)/y2*Y(i,:);
norm12=max(y2-tau,0)+norm12;
    else
X(i,:)= 0*Y(i,:);
    end 
end
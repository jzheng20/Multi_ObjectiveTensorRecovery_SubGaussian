function Y0=Gen_invWaveletTransform(cA,cD,m)

[n1,n2,~]=size(cA);
Y=[];
for i=1:n1
    for j=1:n2
        cAx=cA(i,j,:); cDx=cD(i,j,:);
        Y(i,j,:) = idwt(cAx(:), cDx(:), 'db4', 'mode', 'per');
    end
end
n3=length(Y(i,j,:));
Y0=Y(1:n1,1:n2,1:(n3-m));

end
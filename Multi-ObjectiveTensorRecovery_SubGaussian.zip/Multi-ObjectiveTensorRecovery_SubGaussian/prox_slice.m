function [X, tnn] = prox_slice(Y,rho)

 
% min_X rho*||X||_*+0.5*||X-Y||_F^2
%
 
[n1,n2,n3] = size(Y);
  
X = zeros(n1,n2,n3);
tnn = 0; 
    for i = 1 : n3
        [U,S,V] = svd(Y(:,:,i),'econ');
        S = diag(S);
        r = length(find(S>rho));
        if r >= 1
            S = S(1:r)-rho;
            X(:,:,i) = U(:,1:r)*diag(S)*V(:,1:r)';
            tnn = tnn+sum(S);
        end
    end 
end
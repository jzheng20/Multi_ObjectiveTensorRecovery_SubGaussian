clear all;
clc;


load img_data.mat
Data = double(data);


 delta=0;
 SamplingRate=0.1;

 %Parameters Setting
  opts.DEBUG = 1; 
 opts.max_iter = 500;
 %define transform 
  % transform.L = @fft; transform.l = n3; transform.inverseL = @ifft;
 % transform.L = @dct; transform.l = 1; transform.inverseL = @idct;
  %L = dftmtx(n3); transform.l = n3; transform.L = L;
 % L = dct(eye(n3)); transform.l = 1; transform.L = L;
% L = RandOrthMat(n3); transform.l = 1; transform.L = L; 
 
  alpha0 = 1;  
 alpha3 = 0.001;  
 lambda=1;
 

 vecpsnr=[]; 
for i=1:50%size(Data,3)/3
    X=Data(:,:,1+3*(i-1):3*i);
    X=imresize(X, 0.1);
    X = X/max(X(:));    
    X=shiftdim(X,2);
    maxP = max(abs(X(:)));
    [n1,n2,n3] = size(X);
    Xsize.n1 = n1;
    Xsize.n2 = n2;
    Xsize.n3 = n3;

    m=floor(prod(size(X))*SamplingRate); 
    A = randn(m, prod(size(X)))/sqrt(m);
    z = randn(m, 1) * delta; %~N(0,delta^2); 
    b = A*X(:) + z;
    
    %transform.L = @fft; transform.l = n3; transform.inverseL = @ifft;
    %[Xhat, err] =sparse_tnn_apmm_noiseless(A, b, transform, Xsize, alpha0, alpha3,opts);
      [Xhat, err] =sparse_tnn_wavelet_apmm_noiseless(A, b, Xsize, alpha0, alpha3,opts);
    psnr  = PSNR_high(X,Xhat,maxP)
    vecpsnr=[vecpsnr psnr];
end 
 meanpsnr=mean(vecpsnr); 


filename=['WaveLetimages01_sparse_tnn_noiseless' datestr(now,30) '.mat'];%
save(filename);
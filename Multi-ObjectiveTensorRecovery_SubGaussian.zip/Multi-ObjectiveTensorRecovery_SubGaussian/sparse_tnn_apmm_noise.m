function [Z0, err] = sparse_tnn_apmm_noise(A, b,  transform,Xsize, alpha0, alpha3,lambda, opts)
% b: observation
% A: measurement 

tol = 1e-8; 
max_iter = 1000;
rho = 1.1;
rho_xi=1.1;
mu = 1e-6;
mu2=1e-6;
xi = 1e-6;
max_mu = 1e10;
DEBUG = 1;

if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'max_iter');    max_iter = opts.max_iter;    end
if isfield(opts, 'rho');         rho = opts.rho;              end
if isfield(opts, 'rho_xi');         rho = opts.rho;              end
if isfield(opts, 'mu');          mu = opts.mu;                end
if isfield(opts, 'max_mu');      max_mu = opts.max_mu;        end
if isfield(opts, 'DEBUG');       DEBUG = opts.DEBUG;          end



n1 = Xsize.n1;
n2 = Xsize.n2;
n3 = Xsize.n3;
X = zeros(n1,n2,n3);
dims=[n1,n2,n3];
Z0 = X;
Z3 = X;
m = length(b); 
Y0 = X;
Y3 = X;
I = eye(n1*n2*n3);
%invA = (A'*A+I)\I;
%[Q,R] = qr(A'); %A'=Q*R=>A=R'*Q'=>A'A=Q*(R*R')*Q'
%RRT=R*R';

iter = 0;
for iter = 1 : max_iter
    Xt = X;
    Z0t = Z0; 
    Z3t = Z3;  
    para=(mu+mu2+xi)/(2*lambda);
    invA = (A'*A+para*I)\I; 

    % update Z0 
    tempZ0 = (mu*(X-Y0/mu)+xi*Z0t)/(mu+xi);
    [Z0,Z0tnn] = prox_tnn(tempZ0, alpha0/(mu+xi),transform);
 

    % update X 
    P=(Z0*mu+Y0+mu2*Z3+Y3)/(mu+mu2); 
    tempvecX=((mu+mu2)*P(:)+xi*Xt(:))/(2*lambda); 
     vecX=invA*(A'*b+tempvecX);
     X=reshape(vecX,n1,n2,n3);

         %% Update Zk
         %Z3=Z0;
         k=3;
         tempZ3=(mu2*(X-Y3/mu2)+xi*Z3)/(mu2+xi);
         tempUZ3= lineartransform(tempZ3,transform);
         [unfolding_UZ3,norm12]=soft_row(Unfold(tempUZ3, dims, k),alpha3/(mu2+xi));
         UZ3=Fold(unfolding_UZ3, dims, k);

         Z3=inverselineartransform(UZ3,transform);
    
    %dY1 = A*vecX-b;
    dY0 = Z0-X;
    dY3 = Z3-X;
    chgX = max(abs(Xt(:)-X(:)));
    chgZ0 = max(abs(Z0t(:)-Z0(:)));
    chgZ3 = max(abs(Z3t(:)-Z3(:)));
    chg = max([chgX chgZ0 chgZ3 max(abs(dY0(:))) max(abs(dY3(:)))]);
    if DEBUG
        if iter == 1 || mod(iter, 10) == 0
            obj = alpha0*Z0tnn+alpha3*norm12;
            err = norm(dY0(:))^2+norm(dY3(:))^2;
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                    ', obj=' num2str(obj) ', err=' num2str(err)]); 
        end
    end
    
    if chg < tol
        break;
    end  
    Y0 = Y0 + mu*dY0;
    Y3 = Y3 + mu*dY3;    

    % Update mu, xi
    mu = min(rho*mu,max_mu);  
    mu2= min(rho*mu2,max_mu);
    xi = min(rho_xi*xi,max_mu);  
end
obj = alpha0*Z0tnn+alpha3*norm12;
err =  norm(dY0(:))^2+norm(dY3(:))^2;

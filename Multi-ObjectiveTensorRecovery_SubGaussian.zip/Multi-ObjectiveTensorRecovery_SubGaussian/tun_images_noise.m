clear all;
clc;
X = double(imread('testimg.jpg'));
X=imresize(X,  0.05);
X = X/255;    
X=shiftdim(X,2);
maxP = max(abs(X(:)));
[n1,n2,n3] = size(X);
Xsize.n1 = n1;
Xsize.n2 = n2;
Xsize.n3 = n3;

 delta=0.01;
 SamplingRate=0.3;
 m=floor(prod(size(X))*SamplingRate);


 A = randn(m, prod(size(X)))/sqrt(m);
 z = randn(m, 1) * delta; %~N(0,delta^2); 
 b = A*X(:) + z;
    
 opts.DEBUG = 1; 
 opts.max_iter = 500;
 %define transform 
% transform.L = @fft; transform.l = n3; transform.inverseL = @ifft;
    transform.L = @dct; transform.l = 1; transform.inverseL = @idct;
  %L = dftmtx(n3); transform.l = n3; transform.L = L;
% L = dct(eye(n3)); transform.l = 1; transform.L = L;
% L = RandOrthMat(n3); transform.l = 1; transform.L = L;

 alpha0 = [1]; %[0.001,0.01,0.1,1,10,100];
 alpha3 = [0.001]; %[0.001,0.01,0.1,1,10,100];
 lambda = [1000];
 vecpsnr=[];param=[]; 
 for a0=alpha0
     for a3=alpha3 
         for la=lambda
     [Xhat, err] =sparse_tnn_apmm_noise(A, b, transform, Xsize, a0, a3,la,opts);
      psnr  = PSNR_high(X,Xhat,maxP)
      vecpsnr=[vecpsnr psnr];
      param=[param [a0; a3; la]]; 
         end
     end
     end
 



filename=['image_cs_sparse_tnn_noise' datestr(now,30) '.mat'];%
save(filename);